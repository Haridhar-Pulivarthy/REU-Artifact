static size_t pdf_xobject_size ( pdf_xobject * xobj ) {
 if ( xobj == NULL ) return 0 ;
 return sizeof ( * xobj ) ;
 }