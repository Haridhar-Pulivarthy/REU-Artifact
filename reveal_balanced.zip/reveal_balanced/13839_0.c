static void g2rgb ( fz_context * ctx , fz_color_converter * cc , float * dv , const float * sv ) {
 dv [ 0 ] = sv [ 0 ] ;
 dv [ 1 ] = sv [ 0 ] ;
 dv [ 2 ] = sv [ 0 ] ;
 }