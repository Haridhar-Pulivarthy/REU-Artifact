const SSL_CIPHER * ssl3_get_cipher ( unsigned int u ) {
 if ( u < SSL3_NUM_CIPHERS ) return ( & ( ssl3_ciphers [ SSL3_NUM_CIPHERS - 1 - u ] ) ) ;
 else return ( NULL ) ;
 }