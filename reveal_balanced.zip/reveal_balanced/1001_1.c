static void mspack_fmap_free ( void * mem ) {
 free ( mem ) ;
 }