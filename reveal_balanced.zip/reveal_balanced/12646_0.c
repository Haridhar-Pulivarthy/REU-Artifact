static inline bool e1000e_ring_empty ( E1000ECore * core , const E1000E_RingInfo * r ) {
 return core -> mac [ r -> dh ] == core -> mac [ r -> dt ] || core -> mac [ r -> dt ] >= core -> mac [ r -> dlen ] / E1000_RING_DESC_LEN ;
 }