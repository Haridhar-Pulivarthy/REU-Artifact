void psf_init_files ( SF_PRIVATE * psf ) {
 psf -> file . filedes = - 1 ;
 psf -> rsrc . filedes = - 1 ;
 psf -> file . savedes = - 1 ;
 }