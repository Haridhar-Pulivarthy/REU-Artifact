static PHP_NAMED_FUNCTION ( zif_zip_entry_filesize ) {
 php_zip_entry_get_info ( INTERNAL_FUNCTION_PARAM_PASSTHRU , 2 ) ;
 }