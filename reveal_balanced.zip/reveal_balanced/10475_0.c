static long spl_ptr_llist_count ( spl_ptr_llist * llist ) {
 return ( long ) llist -> count ;
 }