static void check_data_home ( const char * path ) {
 }