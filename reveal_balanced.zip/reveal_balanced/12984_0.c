static struct atom_str * to_atom ( const char * s , unsigned short len ) {
 unsigned int hc = hc_str ( s , len ) % atom_table_sz ;
 struct atom_str * c ;
 for ( c = atom_table [ hc ] ;
 c ;
 c = c -> next_atom ) if ( c -> str_len == len && ! strncmp ( s , c -> str_dat , len ) ) return c ;
 c = pool_alloc ( sizeof ( struct atom_str ) + len + 1 ) ;
 c -> str_len = len ;
 strncpy ( c -> str_dat , s , len ) ;
 c -> str_dat [ len ] = 0 ;
 c -> next_atom = atom_table [ hc ] ;
 atom_table [ hc ] = c ;
 atom_cnt ++ ;
 return c ;
 }