static void rgb2bgr ( fz_context * ctx , fz_color_converter * cc , float * dv , const float * sv ) {
 dv [ 0 ] = sv [ 2 ] ;
 dv [ 1 ] = sv [ 1 ] ;
 dv [ 2 ] = sv [ 0 ] ;
 }