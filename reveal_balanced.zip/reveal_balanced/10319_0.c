static void cmd_server_add ( const char * data ) {
 cmd_server_add_modify ( data , TRUE ) ;
 }