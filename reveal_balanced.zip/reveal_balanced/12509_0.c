static inline PixelTrait GetPixelYellowTraits ( const Image * restrict image ) {
 return ( image -> channel_map [ YellowPixelChannel ] . traits ) ;
 }