static void char_init ( GifCtx * ctx ) {
 ctx -> a_count = 0 ;
 }