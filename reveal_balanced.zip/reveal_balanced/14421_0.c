static ENUM_PTRS_WITH ( gx_ttfReader_enum_ptrs , gx_ttfReader * mptr ) {
 DISCARD ( mptr ) ;
 return 0 ;
 }