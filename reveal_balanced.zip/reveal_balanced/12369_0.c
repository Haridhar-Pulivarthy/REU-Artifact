static void * GenericMPEdup ( struct _cms_typehandler_struct * self , const void * Ptr , cmsUInt32Number n ) {
 return ( void * ) cmsStageDup ( ( cmsStage * ) Ptr ) ;
 cmsUNUSED_PARAMETER ( n ) ;
 cmsUNUSED_PARAMETER ( self ) ;
 }